import tempfile
import unittest
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from superagent.preprocessing.transformers import MultiTextFeatures, preprocessor
from superagent.planning.proposals import apply_proposal
from superagent.planning.search_space import next_candidate


class PairwiseWordBranchTests(unittest.TestCase):
    def setUp(self):
        self.X = pd.DataFrame({
            "headline_A": [
                "Apple launches a new phone",
                "Google launches a new phone",
                "Apple reports record quarterly revenue",
                "Tesla launches electric vehicle",
                "Google reports quarterly earnings",
                "Apple unveils a new device",
            ],
            "headline_B": [
                "Apple reveals its latest smartphone",
                "Google unveils a new phone",
                "Apple shares decline after earnings",
                "Tesla reports vehicle delivery figures",
                "Google announces a new device",
                "Apple releases new software",
            ],
        })
        self.columns = ["headline_A", "headline_B"]

    def make_transformer(self, enabled=True):
        return MultiTextFeatures(
            self.columns,
            analyzer="char_wb",
            representation="difference",
            options={"ngram_range": [3, 6]},
            pairwise_word_features=enabled,
        )

    def test_word_branch_adds_features(self):
        base = self.make_transformer(enabled=False).fit(self.X)
        augmented = self.make_transformer(enabled=True).fit(self.X)
        base_matrix = base.transform(self.X)
        augmented_matrix = augmented.transform(self.X)
        self.assertGreater(augmented_matrix.shape[1], base_matrix.shape[1])

    def test_word_branch_preserves_antisymmetry(self):
        model = self.make_transformer(enabled=True).fit(self.X)
        swapped = pd.DataFrame({
            "headline_A": self.X["headline_B"],
            "headline_B": self.X["headline_A"],
        })
        forward = model.transform(self.X)
        reverse = model.transform(swapped)
        residual = (forward + reverse).tocsr()
        max_error = float(np.max(np.abs(residual.data))) if residual.nnz else 0.0
        self.assertLess(max_error, 1e-6)

    def test_word_branch_survives_joblib_roundtrip(self):
        model = self.make_transformer(enabled=True).fit(self.X)
        expected = model.transform(self.X)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "pairwise_features.joblib"
            joblib.dump(model, path)
            restored = joblib.load(path)
            actual = restored.transform(self.X)
        residual = (expected - actual).tocsr()
        max_error = float(np.max(np.abs(residual.data))) if residual.nnz else 0.0
        self.assertLess(max_error, 1e-7)

    def test_preprocessor_receives_candidate_flag(self):
        profile = {"data_type": "text", "text_columns": self.columns}
        candidate = {
            "family": "logistic",
            "C": 1.0,
            "analyzer": "char_wb",
            "representation": "difference",
            "fit_intercept": False,
            "pairwise_word_features": True,
            "vectorizer_options": {"ngram_range": [3, 6]},
        }
        model = preprocessor(profile, candidate, ".")
        self.assertTrue(model.pairwise_word_features)

    def test_proposal_allows_pairwise_word_feature_flag(self):
        profile = {"data_type": "text", "text_columns": self.columns}
        base = {
            "family": "logistic",
            "C": 1.0,
            "analyzer": "char_wb",
            "representation": "difference",
            "fit_intercept": False,
        }
        result = apply_proposal(base, {"pairwise_word_features": True}, profile)
        self.assertTrue(result["pairwise_word_features"])

    def test_search_space_offers_augmented_candidate_after_baseline(self):
        profile = {
            "data_type": "text",
            "text_columns": self.columns,
            "torch_available": False,
            "compute_profile": "standard",
            "feature_search_enabled": False,
            "minilm_available": False,
        }
        baseline = {
            "family": "logistic",
            "C": 1.0,
            "analyzer": "char_wb",
            "representation": "difference",
            "fit_intercept": False,
            "vectorizer_options": {"ngram_range": [3, 6]},
        }
        history = [
            {"candidate": {"family": "dummy"}, "status": "success"},
            {"candidate": baseline, "status": "success"},
        ]
        candidate, _ = next_candidate(profile, history, "accuracy")
        self.assertTrue(candidate.get("pairwise_word_features", False))


if __name__ == "__main__":
    unittest.main()
