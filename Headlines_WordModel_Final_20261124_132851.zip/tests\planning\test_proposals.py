import unittest
import tempfile
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from superagent.planning.proposals import apply_proposal
from superagent.planning.search_space import build_model
from superagent.config import TaskConfig


class ProposalTests(unittest.TestCase):
    def test_new_parameters_are_bounded_and_cannot_change_execution(self):
        base={'family':'linear_svm','C':1.,'analyzer':'char','representation':'separate'}
        profile={'data_type':'text','text_columns':['a','b']}
        proposed=apply_proposal(base,{'C':.37},profile)
        self.assertEqual(proposed['C'],.37)
        self.assertEqual(base['C'],1.)
        with self.assertRaises(ValueError):
            apply_proposal(base,{'C':.37,'analyzer':'combined'},profile)
        from superagent.planning.memory import trial_key
        with self.assertRaises(ValueError):
            apply_proposal(base, {}, profile, {trial_key(base):base})
        for bad in ({'family':'catboost'},{'code':'print(1)'},{'C':float('nan')},{'C':True},{'C':10000}):
            with self.assertRaises(ValueError):apply_proposal(base,bad,profile)
        with self.assertRaises(ValueError):
            apply_proposal(base,{'representation':'difference'},{'text_columns':['a','b','c']})

    def test_char_wb_pairwise_candidate_is_allowed(self):
        from superagent.planning.proposals import apply_proposal
        from superagent.planning.search_space import next_candidate
        profile = {'data_type': 'text', 'text_columns': ['headline_A', 'headline_B'],
                   'torch_available': False, 'compute_profile': 'standard',
                   'minilm_available': False, 'feature_search_enabled': False}
        base = {'family': 'logistic', 'C': 1.0, 'analyzer': 'char',
                'representation': 'difference'}
        proposed = apply_proposal(base, {'analyzer': 'char_wb'}, profile)
        self.assertEqual(proposed['analyzer'], 'char_wb')
        proposed = apply_proposal(base, {'fit_intercept': False}, profile)
        self.assertFalse(proposed['fit_intercept'])
        history = [
            {'candidate': {'family': 'dummy'}, 'status': 'success', 'score': 0.5},
        ]
        candidate, _ = next_candidate(profile, history, 'accuracy')
        self.assertEqual(candidate['analyzer'], 'char_wb')
        self.assertEqual(candidate['representation'], 'difference')
        self.assertFalse(candidate['fit_intercept'])

    def test_blend_probabilities_and_serialization(self):
        X=pd.DataFrame({'a':['good story','bad story']*12,'b':['bad story','good story']*12})
        profile={'data_type':'text','text_columns':['a','b']}
        model=build_model(profile,{'family':'text_blend','linear_weight':.25,'C':.1},
                          TaskConfig(train_csv='unused',target_column='y'))
        model.fit(X,['yes','no']*12)
        expected=model.predict_proba(X)
        np.testing.assert_allclose(expected.sum(axis=1),1)
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/'m.joblib';joblib.dump(model,p)
            np.testing.assert_allclose(joblib.load(p).predict_proba(X),expected)
