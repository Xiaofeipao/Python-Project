﻿# Task 2 - Headlines CTR Optimization

## Model
Pairwise Word Features + Logistic Regression

## Validation Results
Accuracy: 70.00%
Correct: 658 / 940

## Independent Test Results
Accuracy: 69.275990%
Correct: 2239 / 3232
Test samples: 3232

## Model SHA256
6F099E7A80A1E40259CA929A1E7BE1FAB48DD7D36813EEE1DFC117032CB8A15E

## Evaluation Protocol
The saved model was evaluated on the independent test set.
No retraining or test-set model selection was performed.

## Contents
- Saved model
- Experiment summary and trial history
- Test evaluation report
- Configuration
- Source code snapshots
- Unit tests

The test score was used for final evaluation only.
